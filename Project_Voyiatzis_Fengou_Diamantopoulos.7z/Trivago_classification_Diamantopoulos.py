import pandas as pd
import seaborn as sns
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn import tree
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
import math
from sklearn import preprocessing,metrics
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import GridSearchCV


def string_to_array(s):
    """Convert pipe separated string to array."""
    if isinstance(s, str):
        out = s.split("|")
    elif math.isnan(s):
        out = []
    else:
        raise ValueError("Value must be either string of nan")
    return out

def explode(df_in, col_expl):
    """Explode column col_expl of array type into multiple rows."""
    # Col_expl - "impressions"
    df = df_in.copy()
    df.loc[:, col_expl] = df[col_expl].apply(string_to_array)

    df_out = pd.DataFrame(
        {col: np.repeat(df[col].values,
                        df[col_expl].str.len())
         for col in df.columns.drop(col_expl)}
    )


    df_out.loc[:, col_expl] = np.concatenate(df[col_expl].values)
    df_out.loc[:, col_expl] = df_out[col_expl].apply(str)

    return df_out


df = pd.read_csv('train.csv')

print('The number of rows and columns of the original dataset is:',df.shape)
print('The columns of the original dataset are:\n',df.columns)

df['timestamp']= pd.to_datetime(df['timestamp'],unit='s')

pd.set_option('display.max_columns',None)

maxima= df.groupby('session_id')['timestamp'].max()
df['max']=df['session_id'].map(maxima)
minima = df.groupby('session_id')['timestamp'].min()
df['min']=df['session_id'].map(minima)

df['sessiontime'] =df['max'] - df['min']

df['weekday_weekend'] = df['timestamp'].dt.dayofweek
df.loc[df['weekday_weekend']<4,'weekday_weekend'] = 0
df.loc[df['weekday_weekend']>=4,'weekday_weekend'] = 1

df['usersessions'] = df.groupby('user_id')['session_id'].transform('nunique')

df['sessionsteps'] = df.groupby('session_id')['step'].transform('max')

df['clickornot']=df['action_type'].str.contains('clickout item')
df['clickornot'] = df['clickornot'].apply(lambda x: 0 if not x else 1)

df = df.loc[df['step'] == df['sessionsteps']]

df_1= df[df['clickornot'].eq(1)]
df_1= df_1[['session_id', 'impressions', 'prices']]
df_1['impressions'] = df_1['impressions'].astype(str)
df_1['impressions'] = df_1['impressions'].apply(lambda x: x.split('|'))
df_1['prices'] = df_1['prices'].astype(str)
df_1['prices'] = df_1['prices'].apply(lambda x: x.split('|'))
df_1 = df_1.set_index(['session_id']).apply(pd.Series.explode).reset_index()
df_1.rename(columns = {'impressions': 'reference'}, inplace = True)
df= pd.merge(df, df_1, how = 'left', on = ['session_id', 'reference'])

df.sort_values(['session_id','step'])

df.device.replace({'desktop':0,'tablet':1,'mobile':1},inplace=True)

df=df.drop(columns=['user_id','session_id','timestamp','step','action_type','reference','platform','city','current_filters','impressions','prices_x'])

df.rename(columns={'prices_y':'prices','sessiontime':'session_duration'},inplace=True)

df = df[['device','session_duration','weekday_weekend','usersessions','sessionsteps','prices','clickornot']]

df['session_duration'] = pd.to_timedelta(df.session_duration).dt.total_seconds()

print(df)
print("--------------")

df.to_csv(r'C:\Users\Thodoris\Documents\Deree-Data_Science\Applied Machine Learning\Project\trivago_project.csv',index=False)



df_final = pd.read_csv('trivago_project.csv')

df_final['prices'] = df_final['prices'].fillna(df_final['prices'].median())

print('The number of rows and columns of the resulting dataset is:',df_final.shape)
print('The columns of the resulting dataset are:\n',df_final.columns)

df_final2 = df_final.sample(frac=0.01,random_state=1)
plt.figure(figsize=(10,10))
pairs = sns.pairplot(df_final2,hue='clickornot')
pairs.fig.suptitle('Pair Relationships')
plt.show()

X = df_final.iloc[:, :-1]
Y = df_final.iloc[:, 6]
print(Y.value_counts())

X_train, X_test, Y_train, Y_test = train_test_split (X, Y, test_size = 0.3, shuffle = True, random_state=2)

X_train = preprocessing.scale(np.array(X_train))
Y_train = np.array(Y_train)
X_test = preprocessing.scale(np.array(X_test))
Y_test = np.array(Y_test)


cl_svm = svm.SVC()
cl_dt = tree.DecisionTreeClassifier()
cl_nn = MLPClassifier()
cl_nb = GaussianNB()
cl_knn = KNeighborsClassifier()
cl_rf = RandomForestClassifier()


#Grid Search

parameters_dt = {'criterion': ['gini', 'entropy'],'max_depth': [10, 100, None],'min_samples_leaf': [1, 5, 10]}
grid_dt = GridSearchCV(cl_dt, parameters_dt, n_jobs=-1, cv=4, scoring='f1_macro')
grid_dt.fit(X_train, Y_train)
print('Decision Tree best parameters are:', grid_dt.best_params_)
# Decision Tree best parameters are: {'criterion': 'gini', 'max_depth': 10, 'min_samples_leaf': 5}

parameters_rf = {'n_estimators': [5, 10,50, 100,200],'criterion': ['gini','entropy'],'max_depth': [10, 50, 100, None]}
grid_rf = GridSearchCV(cl_rf, parameters_rf, n_jobs=-1, cv=4, scoring='f1_macro')
grid_rf.fit(X_train, Y_train)
print('Random Forest best parameters are:', grid_rf.best_params_)
# Random Forest best parameters are: {'max_depth': 10, 'n_estimators': 50}

parameters_knn = {'n_neighbors': [3,5]}
grid_knn = GridSearchCV(cl_knn, parameters_knn, n_jobs=-1, cv=4, scoring='f1_macro')
grid_knn.fit(X_train, Y_train)
print('K Nearest Neigbors best parameters are:', grid_knn.best_params_)
# K Nearest Neigbors best parameters are: {'n_neighbors': 3}

# in Neural Network Grid Search more parameter combinations were tried but it was really slow to try many of them compared to the rest
parameters_nn = {'hidden_layer_sizes': [(5,10,5), (10,5, 5)],'activation': ['relu'],'solver': ['adam'],'tol': [1e-7,1e-4],'alpha': [0.0001],'batch_size': [100]}
grid_nn = GridSearchCV(cl_nn, parameters_nn, n_jobs=-1, cv=4, scoring='f1_macro')
grid_nn.fit(X_train, Y_train)
print('Neural Networks best parameters are:', grid_nn.best_params_)
# Neural Networks best parameters are: {'hidden_layer_sizes': (5,10,5), 'activation': 'relu','solver': 'adam', 'tol': 1e-4}, 'alpha': 0.0001, 'batch_size': 100'}
# tol is set to default

#Naive Bayes

cl_nb = GaussianNB()

cl_nb.fit(X_train, Y_train)

Y_train_predict_nb = cl_nb.predict(X_train)

Y_test_predict_nb = cl_nb.predict(X_test)

confusion_nb_train = metrics.confusion_matrix(Y_train, Y_train_predict_nb, labels=None)

confusion_nb_test = metrics.confusion_matrix(Y_test, Y_test_predict_nb, labels=None)

print('Confusion matrix for train set with Naive Bayes')
print(confusion_nb_train)
print('---------------------------------------------------------')

print('Confusion matrix for test set with Naive Bayes')
print(confusion_nb_test)
print('---------------------------------------------------------')

df_nb = pd.DataFrame(confusion_nb_test, index=[1, 0], columns=[1, 0])

plt.figure(figsize=(6, 6),dpi=80)
sns.heatmap(df_nb, annot=True, cmap="PuBu")
plt.ylabel('The Real Class')
plt.xlabel('The Predicted Class')
plt.title('Heatmap for Naive Bayes \nAccuracy:{0:.3f}'.format(accuracy_score(Y_test, Y_test_predict_nb)))
plt.show()


print('Naive Bayes Accuracy for train:', accuracy_score(Y_train, Y_train_predict_nb, normalize=True))
print('Naive Bayes Accuracy for test:', accuracy_score(Y_test, Y_test_predict_nb, normalize=True))
print('---------------------------------------------------------')


print('Naive Bayes(train): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_train, Y_train_predict_nb, average='macro'))

print('Naive Bayes(test): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_test, Y_test_predict_nb, average='macro'))


#Decision Tree

cl_dt = tree.DecisionTreeClassifier(criterion="gini", max_depth=10, min_samples_leaf=5)

cl_dt.fit(X_train, Y_train)

Y_train_prediction_dt = cl_dt.predict(X_train)

Y_test_prediction_dt = cl_dt.predict(X_test)

confusion_dt_train = metrics.confusion_matrix(Y_train, Y_train_prediction_dt, labels=None)

confusion_dt_test = metrics.confusion_matrix(Y_test, Y_test_prediction_dt, labels=None)

print('Confusion matrix for train set with Decision Tree')
print(confusion_dt_train)
print('---------------------------------------------------------')

print('Confusion matrix for test set with Decision Tree')
print(confusion_dt_test)
print('---------------------------------------------------------')

df_dt = pd.DataFrame(confusion_dt_test, index=[1, 0], columns=[1, 0])

plt.figure(figsize=(6, 6),dpi=80)
sns.heatmap(df_dt, annot=True, cmap="PuBu")
plt.ylabel('The Real Class')
plt.xlabel('The Predicted Class')
plt.title('Heatmap for Decision Tree \nAccuracy:{0:.3f}'.format(accuracy_score(Y_test, Y_test_prediction_dt)))
plt.show()

print('Decision Tree Accuracy for train:', accuracy_score(Y_train, Y_train_prediction_dt, normalize=True))
print('Decision Tree Accuracy for test:', accuracy_score(Y_test, Y_test_prediction_dt, normalize=True))
print('---------------------------------------------------------')

print('Decision Tree(train): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_train, Y_train_prediction_dt, average='macro'))

print('Decision Tree(test): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_test, Y_test_prediction_dt, average='macro'))

# The Decision tree is stored in the current directory
# to see the actual tree paste to .dot file to
# http://www.webgraphviz.com/
tree.export_graphviz(cl_dt, out_file='trivago_tree.dot', class_names=['No clickout', 'Clickout'])

feature_names = ['device','session_duration','weekday_weekend','usersessions','sessionsteps','prices']
print('Tree rules=\n', tree.export_text(cl_dt, feature_names=feature_names))

print('Leaves of the Decision Tree:', cl_dt.get_n_leaves())
print('Depth of the Decision Tree:', cl_dt.get_depth())



#Random Forest

cl_rf = RandomForestClassifier(criterion='gini',n_estimators=10, max_depth=50)

cl_rf.fit(X_train, Y_train)

Y_train_prediction_rf = cl_rf.predict(X_train)

Y_test_prediction_rf = cl_rf.predict(X_test)

confusion_rf_train = metrics.confusion_matrix(Y_train, Y_train_prediction_rf, labels=None)

confusion_rf_test = metrics.confusion_matrix(Y_test, Y_test_prediction_rf, labels=None)

print('Confusion matrix for train set with Random Forest')
print(confusion_rf_train)
print('---------------------------------------------------------')

print('Confusion matrix for test set with Random Forest')
print(confusion_rf_test)
print('---------------------------------------------------------')

df_rf = pd.DataFrame(confusion_rf_test, index=[1, 0], columns=[1, 0])

plt.figure(figsize=(6, 6),dpi=80)
sns.heatmap(df_rf, annot=True, cmap="PuBu")
plt.ylabel('The Real Class')
plt.xlabel('The Predicted Class')
plt.title('Heatmap for Random Forest \nAccuracy:{0:.3f}'.format(accuracy_score(Y_test, Y_test_prediction_rf)))
plt.show()

print('Random Forest Accuracy for train:', accuracy_score(Y_train, Y_train_prediction_rf, normalize=True))
print('Random Forest Accuracy for test:', accuracy_score(Y_test, Y_test_prediction_rf, normalize=True))
print('---------------------------------------------------------')

print('Random Forest(train): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_train, Y_train_prediction_rf, average='macro'))

print('Random Forest(test): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_test, Y_test_prediction_rf, average='macro'))


#K Nearest Neighbors

cl_knn = KNeighborsClassifier(n_neighbors=3)

cl_knn.fit(X_train, Y_train)

Y_train_prediction_knn = cl_knn.predict(X_train)

Y_test_prediction_knn = cl_knn.predict(X_test)

confusion_knn_train = metrics.confusion_matrix(Y_train, Y_train_prediction_knn, labels=None)

confusion_knn_test = metrics.confusion_matrix(Y_test, Y_test_prediction_knn, labels=None)

print('Confusion matrix for train set with K Nearest Neighbors')
print(confusion_knn_train)
print('---------------------------------------------------------')

print('Confusion matrix for test set with K Nearest Neighbors')
print(confusion_knn_test)
print('---------------------------------------------------------')

df_knn = pd.DataFrame(confusion_knn_test, index=[1, 0], columns=[1, 0])

plt.figure(figsize=(6, 6),dpi=80)
sns.heatmap(df_knn, annot=True, cmap="PuBu")
plt.ylabel('The Real Class')
plt.xlabel('The Predicted Class')
plt.title('Heatmap for K Nearest Neighbor \nAccuracy:{0:.3f}'.format(accuracy_score(Y_test, Y_test_prediction_knn)))
plt.show()

print('K Nearest Neighbors Accuracy for train:', accuracy_score(Y_train, Y_train_prediction_knn, normalize=True))
print('K Nearest Neighbors Accuracy for test:', accuracy_score(Y_test, Y_test_prediction_knn, normalize=True))
print('---------------------------------------------------------')

print('K Nearest Neighbors(train): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_train, Y_train_prediction_knn, average='macro'))

print('K Nearest Neighbors(test): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_test, Y_test_prediction_knn, average='macro'))


#Neural Networks

cl_nn = MLPClassifier(activation='relu', alpha=0.0001, batch_size=100,hidden_layer_sizes=(5,10,5 ),solver='adam',tol=1e-7)

cl_nn.fit(X_train, Y_train)

Y_train_prediction_nn = cl_nn.predict(X_train)

Y_test_prediction_nn = cl_nn.predict(X_test)

confusion_nn_train = metrics.confusion_matrix(Y_train, Y_train_prediction_nn, labels=None)

confusion_nn_test = metrics.confusion_matrix(Y_test, Y_test_prediction_nn, labels=None)

print('Confusion matrix for train set with Neural Network')
print(confusion_nn_train)
print('---------------------------------------------------------')

print('Confusion matrix for test set with Neural Network')
print(confusion_nn_test)
print('---------------------------------------------------------')

df_nn = pd.DataFrame(confusion_nn_test, index=[1, 0], columns=[1, 0])

plt.figure(figsize=(6, 6),dpi=80)
sns.heatmap(df_nn, annot=True, cmap="PuBu")
plt.ylabel('The Real Class')
plt.xlabel('The Predicted Class')
plt.title('Heatmap for Neural Network \nAccuracy:{0:.3f}'.format(accuracy_score(Y_test, Y_test_prediction_nn)))
plt.show()

print('Neural Network Accuracy for train:', accuracy_score(Y_train, Y_train_prediction_nn, normalize=True))
print('Neural Network Accuracy for test:', accuracy_score(Y_test, Y_test_prediction_nn, normalize=True))
print('---------------------------------------------------------')

print('Neural Network(train): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_train, Y_train_prediction_nn, average='macro'))

print('Neural Network(test): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_test, Y_test_prediction_nn, average='macro'))


predict_y_test_pred_dt = cl_dt.predict_proba(X_test)
#predict_y_test_pred_svm = cl_svm.predict_proba(X_test)
predict_y_test_pred_nn = cl_nn.predict_proba(X_test)
predict_y_test_pred_rf = cl_rf.predict_proba(X_test)
predict_y_test_pred_nb = cl_nb.predict_proba(X_test)
predict_y_test_pred_knn = cl_knn.predict_proba(X_test)

fprDT, tprDT, thresholdsDT = roc_curve(Y_test, predict_y_test_pred_dt[:,1])
#fprSVM, tprSVM, thresholdsSVM = roc_curve(Y_test, predict_y_test_pred_svm[:,1])
fprNN, tprNN, thresholdsNN = roc_curve(Y_test, predict_y_test_pred_nn[:,1])
fprRF, tprRF, thresholdsRF = roc_curve(Y_test, predict_y_test_pred_rf[:,1])
fprNB, tprNB, thresholdsNB = roc_curve(Y_test, predict_y_test_pred_nb[:,1])
fprKNN, tprKNN, thresholdsKNN = roc_curve(Y_test, predict_y_test_pred_knn[:,1])

lw=2
plt.figure(figsize = (10,10),dpi=80)
plt.plot(fprDT,tprDT,lw=lw,color='red',label='Decision Tree')
#plt.plot(fprSVM,tprSVM,lw=lw,color='red',label='Support Vector')
plt.plot(fprNN,tprNN,lw=lw,color='magenta',label='Neural Network')
plt.plot(fprRF,tprRF,lw=lw,color='green',label='Random Forest')
plt.plot(fprNB,tprNB,lw=lw,color='pink',label='Naive Bayes')
plt.plot(fprKNN,tprKNN,lw=lw,color='yellow',label='K Nearest Neighbors')

plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")
plt.show()




#sample

df_final_sample = df_final.sample(frac=0.01,random_state=1)
X_sample = df_final_sample.iloc[:, :-1]
Y_sample = df_final_sample.iloc[:, 6]
X_sample_train, X_sample_test, Y_sample_train, Y_sample_test = train_test_split (X_sample, Y_sample, test_size = 0.3, shuffle = True)

X_sample_train = preprocessing.scale(np.array(X_sample_train))
Y_sample_train = np.array(Y_sample_train)
X_sample_test = preprocessing.scale(np.array(X_sample_test))
Y_sample_test = np.array(Y_sample_test)

cl_sample_svm = svm.SVC()


parameters_sample_svm = {'kernel': ['linear','rbf'],'C': [0.1, 1, 10, 100,1000]}
grid_sample_svm = GridSearchCV(cl_sample_svm, parameters_sample_svm, n_jobs=-1, cv=4, scoring='f1_macro')
grid_sample_svm.fit(X_sample_train, Y_sample_train)
print('Support Vector Machine best parameter:', grid_sample_svm.best_params_)
# SVM best parameter: {'C': 1000, 'kernel': 'rbf'}
# SVM best parameter: {'C': 1, 'kernel': 'linear'}

#Support Vector Machines(linear)

cl_sample_svm = svm.SVC(kernel='linear',probability=True,C=1)
cl_sample_svm.fit(X_sample_train,Y_sample_train)

Y_sample_train_predict_svm = cl_sample_svm.predict(X_sample_train)

Y_sample_test_predict_svm = cl_sample_svm.predict(X_sample_test)

confusion_sample_svm_train = metrics.confusion_matrix(Y_sample_train, Y_sample_train_predict_svm, labels=None)

confusion_sample_svm_test = metrics.confusion_matrix(Y_sample_test, Y_sample_test_predict_svm, labels=None)

print('Confusion matrix for train set with Support Vector Machines(linear)')
print(confusion_sample_svm_train)
print('---------------------------------------------------------')

print('Confusion matrix for test set with Support Vector Machines(linear)')
print(confusion_sample_svm_test)
print('---------------------------------------------------------')


df_sample_svm = pd.DataFrame(confusion_sample_svm_test, index=[1, 0], columns=[1, 0])


plt.figure(figsize=(6, 6),dpi=80)
sns.heatmap(df_sample_svm, annot=True, cmap="PuBu")
plt.ylabel('The Real Class')
plt.xlabel('The Predicted Class')
plt.title('Heatmap for Support Vector Machines(linear) \nAccuracy:{0:.3f}'.format(accuracy_score(Y_sample_test, Y_sample_test_predict_svm)))
plt.show()


print('Support Vector Machines(linear) Accuracy for train:', accuracy_score(Y_sample_train, Y_sample_train_predict_svm, normalize=True))
print('Support Vector Machines(linear) Accuracy for test:', accuracy_score(Y_sample_test, Y_sample_test_predict_svm, normalize=True))
print('---------------------------------------------------------')


print('Support Vector Machines(linear)(train): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_sample_train, Y_sample_train_predict_svm, average='macro'))
print('Support Vector Machines(linear)(test): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_sample_test, Y_sample_test_predict_svm, average='macro'))


predict_sample_y_test_pred_svm = cl_sample_svm.predict_proba(X_sample_test)


fprSVM_sample, tprSVM_sample, thresholdsSVM_sample = roc_curve(Y_sample_test, predict_sample_y_test_pred_svm[:,1])


lw=2
plt.figure(figsize = (10,10),dpi=80)
plt.plot(fprSVM_sample,tprSVM_sample,lw=lw,color='red',label='Support Vector')



plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve Support Vector Machine (linear)')
plt.legend(loc="lower right")
plt.show()


#Support Vector Machines(non-linear)

cl_sample_svm_rbf = svm.SVC(kernel='rbf',probability=True,C=1000)
cl_sample_svm_rbf.fit(X_sample_train,Y_sample_train)

Y_sample_train_predict_svm_rbf = cl_sample_svm_rbf.predict(X_sample_train)

Y_sample_test_predict_svm_rbf = cl_sample_svm_rbf.predict(X_sample_test)


confusion_sample_svm_train_rbf = metrics.confusion_matrix(Y_sample_train, Y_sample_train_predict_svm_rbf, labels=None)

confusion_sample_svm_test_rbf = metrics.confusion_matrix(Y_sample_test, Y_sample_test_predict_svm_rbf, labels=None)

print('Confusion matrix for train set with Support Vector Machines(non-linear)')
print(confusion_sample_svm_train_rbf)
print('---------------------------------------------------------')

print('Confusion matrix for test set with Support Vector Machines(non-linear)')
print(confusion_sample_svm_test_rbf)
print('---------------------------------------------------------')


df_sample_svm_rbf = pd.DataFrame(confusion_sample_svm_test_rbf, index=[1, 0], columns=[1, 0])

plt.figure(figsize=(6, 6),dpi=80)
sns.heatmap(df_sample_svm_rbf, annot=True, cmap="PuBu")
plt.ylabel('The Real Class')
plt.xlabel('The Predicted Class')
plt.title('Heatmap for Support Vector Machines(non-linear) \nAccuracy:{0:.3f}'.format(accuracy_score(Y_sample_test, Y_sample_test_predict_svm_rbf)))
plt.show()


print('Support Vector Machines(non-linear) Accuracy for train:', accuracy_score(Y_sample_train, Y_sample_train_predict_svm_rbf, normalize=True))
print('Support Vector Machines(non-linear) Accuracy for test:', accuracy_score(Y_sample_test, Y_sample_test_predict_svm_rbf, normalize=True))
print('---------------------------------------------------------')

print('Support Vector Machines(non-linear)(train): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_sample_train, Y_sample_train_predict_svm_rbf, average='macro'))
print('Support Vector Machines(non-linear)(test): Macro Precision, recall, f1-score')
print(metrics.precision_recall_fscore_support(Y_sample_test, Y_sample_test_predict_svm_rbf, average='macro'))


predict_sample_y_test_pred_svm_rbf = cl_sample_svm_rbf.predict_proba(X_sample_test)


fprSVM_rbf_sample, tprSVM_rbf_sample, thresholdsSVM_rbf_sample = roc_curve(Y_sample_test, predict_sample_y_test_pred_svm_rbf[:,1])


lw=2
plt.figure(figsize = (10,10),dpi=80)
plt.plot(fprSVM_rbf_sample,tprSVM_rbf_sample,lw=lw,color='red',label='Support Vector')



plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve Support Vector Machine (non-linear)')
plt.legend(loc="lower right")
plt.show()